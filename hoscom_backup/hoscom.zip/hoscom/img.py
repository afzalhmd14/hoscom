import cv2
import numpy as np

img=np.zeros((100,100),np.uint8)
img[:100,:50]=50
img[:100,50:]=200
'''img=cv2.imread("2")
img=cv2.pyrDown(img)
img=cv2.pyrDown(img)
img=cv2.pyrDown(img)'''
cv2.imwrite('1.jpg',img)
import time
import serial
import os

file="1.jpg"
ser = serial.Serial('/dev/ttyACM1', 9600,timeout=5) # Establish the connection on a specific port
time.sleep(0.1)
f = open(file, "r")
b=os.path.getsize(file)

start=time.time()
u=0
byte = f.read(1)
while byte!="":
	i=0
	if byte!=None:
		while(i==0):
			time.sleep(0.01)
			i=ser.write(byte)
		if(u%(1024)==0):
			done_percent=100*float(u)/b
			diff=time.time()-start
			if diff is not 0:
				print int(done_percent)," %_ done. (",(u/1024),"KB), Time elapsed: ",diff," seconds @ ",(float(u/(1024*(diff))))," KB/s"
	byte = f.read(1)
	u+=1

end=time.time()
print "Time taken to transfer ",(b/1024)," KB is",(end-start), "secs @ ",(b/(1024*(end-start))), " KB/s."
f.close()
ser.close()